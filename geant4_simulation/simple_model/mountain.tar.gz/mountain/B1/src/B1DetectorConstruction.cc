//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
// $Id$
//
/// \file B1DetectorConstruction.cc
/// \brief Implementation of the B1DetectorConstruction class

#include "B1DetectorConstruction.hh"
#include "B1SteppingAction.hh"
   // use of stepping action to set the accounting volume

#include "G4RunManager.hh"
#include "G4NistManager.hh"
#include "G4Box.hh"
#include "G4Cons.hh"
#include "G4Orb.hh"
#include "G4Sphere.hh"
#include "G4Trd.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4SystemOfUnits.hh"
#include "G4TessellatedSolid.hh"
#include "G4VFacet.hh"
#include "G4TriangularFacet.hh"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1DetectorConstruction::B1DetectorConstruction()
: G4VUserDetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

B1DetectorConstruction::~B1DetectorConstruction()
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

G4VPhysicalVolume* B1DetectorConstruction::Construct()
{  
  // Get nist material manager
  G4NistManager* nist = G4NistManager::Instance();
  
  // Envelope parameters
  //
  G4double env_sizeXY = 20*cm, env_sizeZ = 30*cm;
  G4Material* env_mat = nist->FindOrBuildMaterial("G4_WATER");
   
  // Option to switch on/off checking of volumes overlaps
  //
  G4bool checkOverlaps = true;

  //     
  // World
  //
  G4double world_sizeXY = 1.2*env_sizeXY;
  G4double world_sizeZ  = 1.2*env_sizeZ;
  G4Material* world_mat = nist->FindOrBuildMaterial("G4_AIR");
  
  G4Box* solidWorld =    
    new G4Box("World",                       //its name
       0.5*world_sizeXY, 0.5*world_sizeXY, 0.5*world_sizeZ);     //its size
      
  G4LogicalVolume* logicWorld =                         
    new G4LogicalVolume(solidWorld,          //its solid
                        world_mat,           //its material
                        "World");            //its name
                                   
  G4VPhysicalVolume* physWorld = 
    new G4PVPlacement(0,                     //no rotation
                      G4ThreeVector(),       //at (0,0,0)
                      logicWorld,            //its logical volume
                      "World",               //its name
                      0,                     //its mother  volume
                      false,                 //no boolean operation
                      0,                     //copy number
                      checkOverlaps);        //overlaps checking
                     
  //     
  // Envelope
  //  
  G4Box* solidEnv =    
    new G4Box("Envelope",                    //its name
        0.5*env_sizeXY, 0.5*env_sizeXY, 0.5*env_sizeZ); //its size
      
  G4LogicalVolume* logicEnv =                         
    new G4LogicalVolume(solidEnv,            //its solid
                        env_mat,             //its material
                        "Envelope");         //its name
               
  new G4PVPlacement(0,                       //no rotation
                    G4ThreeVector(),         //at (0,0,0)
                    logicEnv,                //its logical volume
                    "Envelope",              //its name
                    logicWorld,              //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking
 
  //     
  // Shape 1
  //
  /*
  G4ThreeVector pos11 = G4ThreeVector( 1,  1*cm, 1*cm);
  G4ThreeVector pos12 = G4ThreeVector( 1, -1*cm, 2*cm);
  G4ThreeVector pos12 = G4ThreeVector(-1,  1*cm, 3*cm);
  G4ThreeVector pos22 = G4ThreeVector(-1, -1*cm, 4*cm);
*/
    
  G4ThreeVector malla[4][4];

  malla[0][0] = G4ThreeVector( 0.*cm,  0.*cm, 2*cm);
  malla[1][0] = G4ThreeVector( 2*cm,  0*cm, 4*cm);
  malla[2][0] = G4ThreeVector( 4*cm,  0*cm, 6*cm);
  malla[3][0] = G4ThreeVector( 6*cm,  0*cm, 8*cm);


  malla[0][1] = G4ThreeVector( 0.*cm,  2*cm, 3*cm);
  malla[1][1] = G4ThreeVector( 2*cm,  2*cm, 5*cm);
  malla[2][1] = G4ThreeVector( 4*cm,  2*cm, 7*cm);
  malla[3][1] = G4ThreeVector( 6*cm,  2*cm, 9*cm);


  malla[0][2] = G4ThreeVector(  0*cm,  4*cm, 1*cm);
  malla[1][2] = G4ThreeVector( 2*cm,  4*cm, 3*cm);
  malla[2][2] = G4ThreeVector( 4*cm,  4*cm, 7*cm);
  malla[3][2] = G4ThreeVector( 6*cm,  4*cm, 9*cm);

  malla[0][3] = G4ThreeVector(  0*cm,  6*cm, 2*cm);
  malla[1][3] = G4ThreeVector( 2*cm,  6*cm, 4*cm);
  malla[2][3] = G4ThreeVector( 4*cm,  6*cm, 6*cm);
  malla[3][3] = G4ThreeVector( 6*cm,  6*cm, 8*cm);	

  G4Material* shape1_mat = nist->FindOrBuildMaterial("G4_A-150_TISSUE");
  G4ThreeVector pos1 = G4ThreeVector(0, 0*cm, 0*cm);
/*        
  // Conical section shape       
  G4double shape1_rmina =  0.*cm, shape1_rmaxa = 2.*cm;
  G4double shape1_rminb =  0.*cm, shape1_rmaxb = 4.*cm;
  G4double shape1_hz = 3.*cm;
  G4double shape1_phimin = 0.*deg, shape1_phimax = 360.*deg;
  G4Cons* solidShape1 =    
    new G4Cons("Shape1", 
    shape1_rmina, shape1_rmaxa, shape1_rminb, shape1_rmaxb, shape1_hz,
    shape1_phimin, shape1_phimax);
*/
/*
  // Full sphere shape
  G4double shape1_rmax = 4*cm;
  G4Orb* solidShape1 =    
    new G4Orb("Shape1",                     //its name
              shape1_rmax);                 //its size

  // Sphere shape
  G4double shape1_rmin = 0*cm, shape1_rmax = 4*cm;
  G4double shape1_thetamin = 0.*deg, shape1_thetamax =  180.*deg;    
  G4double shape1_phimin = 0.*deg, shape1_phimax =  360.*deg;    
  G4Sphere* solidShape1 =    
    new G4Sphere("Shape1",                  //its name
        shape1_rmin, shape1_rmax,                //its size
        shape1_phimin, shape1_phimax,            //phi angle
        shape1_thetamin, shape1_thetamax);       //theta angle
     
  // Box shape
  G4double shape1_dx = 8*cm, shape1_dy = 8*cm, shape1_dz = 8*cm;    
  G4Box* solidShape1 =    
    new G4Box("Shape1",                     //its name
         0.5*shape1_dx, 0.5*shape1_dy, 0.5*shape1_dz);     //its size
*/
  

////////////   Aca empieza mi experimento

//      First declare a tessellated solid:  
G4TessellatedSolid* solidTarget = new G4TessellatedSolid("Solid_name");
  
//      Define the facets which form the solid
       

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	G4ThreeVector vertex_1, vertex_2, vertex_3;

        vertex_1 = G4ThreeVector( malla[0][3].getX() , malla[0][3].getY(), 0); 
        vertex_2 = G4ThreeVector( malla[3][3].getX() , malla[3][3].getY(), 0); 
	vertex_3 = G4ThreeVector( malla[0][0].getX() , malla[0][0].getY(), 0); 


        G4TriangularFacet * facet_1;
         facet_1 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         solidTarget->AddFacet((G4VFacet*) facet_1);

        vertex_1 = G4ThreeVector( malla[0][0].getX() , malla[0][0].getY(), 0); 
        vertex_2 = G4ThreeVector( malla[3][3].getX() , malla[3][3].getY(), 0);
	vertex_3 = G4ThreeVector( malla[3][0].getX() , malla[3][0].getY(), 0); 

        G4TriangularFacet * facet_2;
         facet_2 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         solidTarget->AddFacet((G4VFacet*) facet_2);
   

        for (int i=0;i<4-1;i++){
        for (int j=0;j<4-1;j++){ 
        
         vertex_1 = malla[i][j];
         vertex_2 = malla[i+1][j];
	 vertex_3 = malla[i+1][j+1];
      
	 G4TriangularFacet * facet_3;
         facet_3 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         solidTarget->AddFacet((G4VFacet*) facet_3);
     
         vertex_1 = malla[i][j];
         vertex_2 = malla[i+1][j+1];
	 vertex_3 = malla[i][j+1];
    
         G4TriangularFacet * facet_4;
         facet_4 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);
         solidTarget->AddFacet((G4VFacet*) facet_4);


        };
	};

 	for (int i=0;i<4-1;i++){
                
		vertex_1 = malla[i+1][0];
		vertex_2 = malla[i][0];
		vertex_3 = G4ThreeVector( malla[i][0].getX() , malla[i][0].getY(), 0); 

		G4TriangularFacet * facet_5;
         	facet_5 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         	solidTarget->AddFacet((G4VFacet*) facet_5);

		vertex_1 = G4ThreeVector( malla[i][0].getX() , malla[i][0].getY(), 0); 
		vertex_2 = G4ThreeVector( malla[i+1][0].getX() , malla[i+1][0].getY(), 0); 
		vertex_3 = malla[i+1][0];

		G4TriangularFacet * facet_6;
	         facet_6 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
	         solidTarget->AddFacet((G4VFacet*) facet_6);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////

		vertex_1 = malla[0][i];
		vertex_2 = malla[0][i+1];
		vertex_3 = G4ThreeVector( malla[0][i].getX() , malla[0][i].getY(), 0); 

		G4TriangularFacet * facet_7;
         	facet_7 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         	solidTarget->AddFacet((G4VFacet*) facet_7);

		vertex_1 = G4ThreeVector( malla[0][i].getX()   , malla[0][i].getY(), 0); 
		vertex_2 = malla[0][i+1];
		vertex_3 = G4ThreeVector( malla[0][i+1].getX() , malla[0][i+1].getY(), 0); 

		G4TriangularFacet * facet_8;
         	facet_8 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         	solidTarget->AddFacet((G4VFacet*) facet_8);

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		vertex_1 = malla[i+1][3];
		vertex_2 = G4ThreeVector( malla[i][3].getX() , malla[i][3].getY(), 0); 
		vertex_3 = malla[i][3];

		G4TriangularFacet * facet_9;
         	facet_9 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         	solidTarget->AddFacet((G4VFacet*) facet_9);

		vertex_1 = G4ThreeVector( malla[i][3].getX() , malla[i][3].getY(), 0); 
		vertex_2 = malla[i+1][3];
		vertex_3 = G4ThreeVector( malla[i+1][3].getX() , malla[i+1][3].getY(), 0); 

		G4TriangularFacet * facet_10;
         	facet_10 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         	solidTarget->AddFacet((G4VFacet*) facet_10);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

		vertex_1 = malla[3][i+1];
		vertex_3 = G4ThreeVector( malla[3][i].getX() , malla[3][i].getY(), 0); 
		vertex_2 = malla[3][i];

		G4TriangularFacet * facet_11;
	         facet_11 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
	         solidTarget->AddFacet((G4VFacet*) facet_11);


		vertex_1 = G4ThreeVector( malla[3][i].getX() , malla[3][i].getY(), 0); 
		vertex_2 = G4ThreeVector( malla[3][i+1].getX() , malla[3][i+1].getY(), 0); 
		vertex_3 = malla[3][i+1];

		G4TriangularFacet * facet_12;
         	facet_12 = new G4TriangularFacet (vertex_1, vertex_2, vertex_3, ABSOLUTE);         
         	solidTarget->AddFacet((G4VFacet*) facet_12);


	};

  
//      Finally declare the solid is complete:
  
        solidTarget->SetSolidClosed(true);

//aca termina

                    
  G4LogicalVolume* logicShape1 =                         
    new G4LogicalVolume(solidTarget,         //its solid
                        shape1_mat,          //its material
                        "Shape1");           //its name
               
  new G4PVPlacement(0,                       //no rotation
                    pos1,                    //at position
                    logicShape1,             //its logical volume
                    "Shape1",                //its name
                    logicEnv,                //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking


  //     
  // Shape 2
  //
  G4Material* shape2_mat = nist->FindOrBuildMaterial("G4_BONE_COMPACT_ICRU");
  G4ThreeVector pos2 = G4ThreeVector(0, -7*cm, 7*cm);
/*
  //  Shape 2 - conical section shape       
   G4double shape2_rmina =  0.*cm, shape2_rmaxa = 5.*cm;
   G4double shape2_rminb =  0.*cm, shape2_rmaxb = 8.*cm;
   G4double shape2_hz = 3.*cm;
   G4double shape2_phimin = 0.*deg, shape2_phimax = 360.*deg;
   G4Cons* solidShape2 =    
     new G4Cons("Shape2", 
     shape2_rmina, shape2_rmaxa, shape2_rminb, shape2_rmaxb, shape2_hz,
     shape2_phimin, shape2_phimax);
*/

  // Trapezoid shape       
  G4double shape2_dxa = 12*cm, shape2_dxb = 12*cm;
  G4double shape2_dya = 10*cm, shape2_dyb = 16*cm;
  G4double shape2_dz  = 6*cm;      
  G4Trd* solidShape2 =    
    new G4Trd("Shape2",                      //its name
              0.5*shape2_dxa, 0.5*shape2_dxb, 
              0.5*shape2_dya, 0.5*shape2_dyb, 0.5*shape2_dz); //its size
                
  G4LogicalVolume* logicShape2 =                         
    new G4LogicalVolume(solidShape2,         //its solid
                        shape2_mat,          //its material
                        "Shape2");           //its name
               
  new G4PVPlacement(0,                       //no rotation
                    pos2,                    //at position
                    logicShape2,             //its logical volume
                    "Shape2",                //its name
                    logicEnv,                //its mother  volume
                    false,                   //no boolean operation
                    0,                       //copy number
                    checkOverlaps);          //overlaps checking
                
  // Set scoring volume to stepping action 
  // (where we will account energy deposit)
  //
  B1SteppingAction* steppingAction = B1SteppingAction::Instance(); 
  ////steppingAction->SetVolume(logicShape1);
  steppingAction->SetVolume(logicShape2);


  //
  //always return the physical World
  //
  return physWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
